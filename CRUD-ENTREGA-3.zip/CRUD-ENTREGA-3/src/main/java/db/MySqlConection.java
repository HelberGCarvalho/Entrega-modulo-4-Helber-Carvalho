package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySqlConection {
	
	private static final String url = "jdbc:mysql://localhost:3306/helberjbdc";
	private static final String usuario = "root";
	private static final String senha = "Eub141688888@";
	
	public static Connection createConnection() {
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Drive Encontrado!");
			
		} catch (ClassNotFoundException e) {
			System.out.println("Drive n�o Encontrado! " + e.getMessage());
			
		}
		
		try {
			Connection connection = DriverManager.getConnection(url, usuario, senha);
			System.out.println("Conectado com o Banco de Dados.");
			return connection;
		
		} catch (SQLException e) {
			System.out.println("N�o conectado com o Banco de Dados " + e.getErrorCode());
			return null;
			
		}
		
	}
}

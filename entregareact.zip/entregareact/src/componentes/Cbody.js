import React from 'react';
import './Cbody.css';



function Cbody() {
    return (
<>
   <div className='container'>

                        
						<h3>Deixe seus contatos para que possamos enviar nossas promoçoes</h3>
						

						<form action="CreateAndFind" method="post">
							<div class="form-floating mb-3">
								<input name="nome" maxlength="40" type="text"
									class="form-control" id="floatingInput1"/> <label>Nome
									completo</label>
							</div>
							<div class="form-floating mb-3">
								<input name="cpf" maxlength="11" type="text"
									class="form-control"/> <label>CPF (apenas
									números)</label>
							</div>
							<div class="form-floating mb-3">
								<input name="endereco" maxlength="50" type="text"
									class="form-control"/> <label>Endereço (Rua - N°
									- Bairro - Cidade - UF)</label>
							</div>
							<div class="form-floating mb-3">
								<input name="email" maxlength="40" type="text"
									class="form-control"/> <label>Email</label>
							</div>
							

							<button class="btn btn-primary" type="submit">Cadastrar
								Cliente</button>
							<button class="btn btn-secondary" type="reset">Limpar
								Formulário</button> <br/>


						</form>
                        <br/>
    
    
    
                        </div>
    
 
    </>
    );
}

export default Cbody;
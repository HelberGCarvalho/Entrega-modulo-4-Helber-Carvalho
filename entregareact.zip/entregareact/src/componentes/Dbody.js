import React from "react";
import './Dbody.css';




function Dbody() {
    return (
<>

<div className="container">

   
<section className="secUm">

<div className="divSecUm-um">
  
  <div className="contentpromo">
      <div className="card">
        <div className="topCard">
          <h2 className="title"></h2>
          <span className="secondText"></span>
       </div>
       
       <div className="mediaCard"></div>
       <div className="bottomCard">
           <h2> <strong>Fortaleza</strong> </h2>
           <span className="bottomText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, 
               ratione! Recusandae perspiciatis ratione dolor distinctio tempore, vel labore tenetur 
               porro quidem laborum</span>
           <div class="actionCards">
               <button className="actions">Confira</button>
 
           </div>
         </div>
      </div>
 
    </div>
</div>

<div className="divSecUm-dois">
  
  <div className="contentpromo">
      <div className="card">
        <div className="topCard">
          <h2 className="title"></h2>
          <span className="secondText"></span>
       </div>
       
       <div className="mediaCard2"></div>
       <div className="bottomCard">
           <h2> <strong>São Paulo</strong> </h2>
           <span className="bottomText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, 
               ratione! Recusandae perspiciatis ratione dolor distinctio tempore, vel labore tenetur 
               porro quidem laborum</span>
           <div className="actionCards">
               <button className="actions">Confira</button>
 
           </div>
         </div>
      </div>
 
    </div>

</div>

</section>

<section className="secDois">

  <div className="divSecDois-um">
    
    <div className="contentpromo">
        <div className="card">
          <div className="topCard">
            <h2 className="title"></h2>
            <span class="secondText"></span>
         </div>
         
         <div className="mediaCard3"></div>
         <div className="bottomCard">
             <h2> <strong>Rio de Janeiro</strong> </h2>
             <span className="bottomText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, 
                 ratione! Recusandae perspiciatis ratione dolor distinctio tempore, vel labore tenetur 
                 porro quidem laborum</span>
             <div className="actionCards">
                 <button className="actions">Confira</button>
   
             </div>
           </div>
        </div>
   
      </div>
  </div>
  
  <div className="divSecDois-dois">
    
    <div className="contentpromo">
        <div className="card">
          <div className="topCard">
            <h2 className="title"></h2>
            <span className="secondText"></span>
         </div>
         
         <div className="mediaCard4"></div>
         <div className="bottomCard">
             <h2> <strong>Gramado</strong> </h2>
             <span className="bottomText">Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, 
                 ratione! Recusandae perspiciatis ratione dolor distinctio tempore, vel labore tenetur 
                 porro quidem laborum</span>
             <div className="actionCards">
                 <button className="actions">Confira</button>
   
             </div>
           </div>
        </div>
   
      </div>

  </div>

</section>

</div>

</>
    );
}

export default Dbody;
import React from "react";
import { Link } from "react-router-dom";

import Navbar from "./Navbar";
import Header from "./Header";
import Footer from "./Footer";
import Dbody from "./Dbody";

const Destinos = () => {

    return (
        <>
    <Navbar/>
    
    <Header/>

    <Dbody/>

    <Footer/>

  

    


</>
);

}

export default Destinos;


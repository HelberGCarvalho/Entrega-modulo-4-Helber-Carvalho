import React from "react";
import { Link } from "react-router-dom";

import Navbar from "./Navbar";
import Header from "./Header";
import Footer from "./Footer";
import Pbody from "./Pbody";



const Promo = () => {

    return (
<>

<Navbar/>
<Header/>
<Pbody/>
<Footer/>

    


</>
);

}

export default Promo;